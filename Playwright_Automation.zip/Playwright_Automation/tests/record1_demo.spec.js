const { test, expect } = require('@playwright/test');

test('Erfolgreicher Test: Title check', async ({ page }) => {
  await page.goto('https://playwright.dev/docs/writing-tests');
  await expect(page).toHaveTitle(/Writing Tests/);
});

test('Fehlschlag-Test: Erwarteter Text existiert nicht', async ({ page }) => {
  await page.goto('https://playwright.dev/docs/writing-tests');

  // Wir suchen ein Element, das mit Absicht **nicht existiert**
  const notExistingElement = page.locator('text=DiesIstEinFehlerDerNieExistiert');

  // Das wird garantiert fehlschlagen:
  await expect(notExistingElement).toBeVisible();
});
