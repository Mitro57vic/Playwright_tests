const { test, expect } = require('@playwright/test');

test('Search returns results on DuckDuckGo', async ({ page }) => {
  await page.goto('https://duckduckgo.com');
  await page.fill('input[name="q"]', 'Playwright');
  await page.press('input[name="q"]', 'Enter');
});